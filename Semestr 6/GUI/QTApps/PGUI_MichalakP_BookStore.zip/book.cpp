#include "book.h"

Book::Book(const int id, const QString& author, const QString& title): id(id), title(title), author(author) {}
