#include "person.h"

Person::Person(int id, const QString &name, const QString &surname,
               const QString &phone_number, const QString &email):
               id(id),name(name),surname(surname),phone_number(phone_number), email(email){}
