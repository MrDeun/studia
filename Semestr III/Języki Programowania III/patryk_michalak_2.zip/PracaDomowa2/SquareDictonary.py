def squaredictonary():
    squareDictonary = dict()
    for iterator in range(0,16):
        squareDictonary.update({iterator:iterator*iterator})
    print(squareDictonary)

squaredictonary()
