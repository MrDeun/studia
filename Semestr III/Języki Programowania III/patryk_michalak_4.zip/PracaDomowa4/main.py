#1.Napisz funkcję zamieniającą liczbę całkowitą na liczbę zapisaną za pomocą cyfr rzymskich
import zadanie1
#2.Napisz funkcję, która dla podanych liczb da odpowiedź o ich monotoniczności (rosnące, malejące, inne)
import zadanie2
#3.Wylicz XOR w postaci binarnej dla podanych w systemie dziesiętnym liczb
import zadanie3
#4.Dla podanej listy zawierającej liczby stwórz funkcję podającą posortowaną według sumy cyfr ich listę
import zadanie4

print(zadanie1.intToRoman(41))

print(zadanie2.monotonicity_check([5,6,7,10,10]))

print(zadanie3.int_xor(6,20))

print(zadanie4.sort_by_digit([20,30,4,63,2,15]))