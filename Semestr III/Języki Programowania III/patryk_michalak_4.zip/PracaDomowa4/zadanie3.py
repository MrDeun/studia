def int_xor(number1:int,number2:int):
    result = number1 ^ number2
    print(bin(result))