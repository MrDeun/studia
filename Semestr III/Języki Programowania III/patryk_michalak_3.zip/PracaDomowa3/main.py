import zadanie1
import zadanie2
import zadanie3
import zadanie4



print("6. Iteracja Fibonacciego to: ",zadanie1.value_of_fib(6))

list = [-2,-1,0,1,2,3]

print(list," VS ",zadanie2.eradicate_negatives(list))

punkt = zadanie3.Point(0,0)
trojkat = zadanie3.Triangle(0,0,3,0,0,3)
print(zadanie3.isInside(trojkat,punkt))

