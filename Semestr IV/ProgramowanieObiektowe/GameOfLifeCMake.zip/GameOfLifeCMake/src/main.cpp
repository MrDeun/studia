//
// Created by Patryk on 12-Apr-24.
//
#include "game_txt.h"

int main(){
    std::cout << "Hello World!" << std::endl;
    game_txt instance;
    instance.start();
}